"""
进程内串接：午间行情盘点与下午操作指引（report_type=midday_recap）。

注意：Cron 任务推荐单次调用 `tool_run_midday_recap_and_send`，避免多轮工具调用与 idle 超时。
本 runner 以“可用即发”为原则：尽量采集关键字段，缺失则在 report_data 中标注。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple


def _now_sh() -> datetime:
    # 与其它 runner 保持一致（不强依赖 pytz）
    return datetime.now()


def _safe_step(name: str, fn: Any, errors: List[Dict[str, str]], /, **kwargs: Any) -> Any:
    try:
        return fn(**kwargs)
    except Exception as e:
        errors.append({"step": name, "error": f"{e}"})
        return {"success": False, "message": f"{name} failed: {e}"}


def build_midday_recap_report_data(fetch_mode: str = "production") -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    """
    采集并组装 report_data（含 report_type=midday_recap）。
    返回 (report_data, runner_errors)。
    """
    errors: List[Dict[str, str]] = []
    mode = fetch_mode if fetch_mode in ("production", "test") else "production"
    now = _now_sh()

    from plugins.data_collection.limit_up.sector_heat import tool_sector_heat_score
    from plugins.merged.fetch_etf_data import tool_fetch_etf_data
    from plugins.merged.fetch_index_data import tool_fetch_index_data
    from plugins.risk.portfolio_risk_snapshot import tool_portfolio_risk_snapshot

    rd: Dict[str, Any] = {
        "report_type": "midday_recap",
        "runner_version": "midday_recap_composite_v1",
        "generated_at": now.strftime("%Y-%m-%d %H:%M:%S"),
    }

    # 1) 指数/ETF 概览（尽量少依赖 schema；缺字段时留空）
    idx = _safe_step(
        "fetch_index_realtime",
        tool_fetch_index_data,
        errors,
        data_type="realtime",
        mode=mode,
        index_codes="000300,399006,000905",
    )
    rd["tool_fetch_index_realtime"] = idx

    etf510 = _safe_step(
        "fetch_etf_realtime_510300",
        tool_fetch_etf_data,
        errors,
        data_type="realtime",
        etf_code="510300",
        mode=mode,
    )
    rd["tool_fetch_etf_realtime_510300"] = etf510

    # 2) 板块热度（涨停侧）
    heat = _safe_step("sector_heat_score", tool_sector_heat_score, errors)
    rd["tool_sector_heat_score"] = heat

    # 3) 组合风险快照
    risk = _safe_step("portfolio_risk_snapshot", tool_portfolio_risk_snapshot, errors)
    rd["tool_portfolio_risk_snapshot"] = risk

    # 将 formatter 需要的字段塞进 midday_recap
    mr: Dict[str, Any] = {
        "date": now.strftime("%Y-%m-%d"),
        "non_trading": False,
        "market_state_label": "N/A",
        "session_note": "",
        "fund_flow_data_note": "本仓库未内置 A 股资金流向工具；如需请由 openclaw-data-china-stock 扩展提供。",
        "fund_flow_summary_lines": [],
        "sector_rank_lines": [],
        "sector_heat_tool": heat,
        "opening_expectation": {"available": False},
        "afternoon_bias": "N/A",
        "afternoon_bias_rationale": "N/A",
        "afternoon_advice": {
            "session_basis": "本报告仅提供多视角参考；缺字段时按 N/A 展示。",
            "trend": {"action": "N/A", "reason": ""},
            "timing": {"action": "N/A", "reason": ""},
            "risk": {"action": "N/A", "reason": ""},
            "paths": {
                "conservative": {"action": "hold", "cap": "N/A"},
                "neutral": {"action": "hold", "cap": "N/A"},
                "aggressive": {"action": "hold", "cap": "N/A"},
                "default_path": "中性",
            },
        },
        "cross_border_lines": [],
        "time_reminders": ["13:00 关注回补缺口/承接强度变化", "14:30 关注券商/权重异动与指数脉冲"],
        "user_decision_note": "本系统仅提供多视角信息，不替代你的最终交易决策。",
    }

    # 半日成交额代理（尽可能从 ETF realtime 中取）
    amt = None
    if isinstance(etf510, dict) and isinstance(etf510.get("data"), dict):
        d = etf510["data"]
        for k in ("amount", "turnover", "成交额", "成交额(元)", "成交额(万元)"):
            if k in d:
                amt = d.get(k)
                break
    mr["morning_amount_510300"] = amt

    # 简单扁平化：若 index realtime 返回可解析涨跌，写入 inspection_flat
    flat: Dict[str, Any] = {}
    if isinstance(idx, dict):
        data = idx.get("data")
        # tool_fetch_index_data 可能返回 list[dict] 或 dict
        rows = data if isinstance(data, list) else (data.get("records") if isinstance(data, dict) else None)
        if isinstance(rows, list):
            by = {}
            for r in rows:
                if not isinstance(r, dict):
                    continue
                code = str(r.get("code") or r.get("index_code") or r.get("symbol") or "")
                if code:
                    by[code] = r
            flat["hs300_change"] = by.get("000300", {}).get("change_pct") or by.get("000300", {}).get("change_percent")
            flat["gem_change"] = by.get("399006", {}).get("change_pct") or by.get("399006", {}).get("change_percent")
            flat["zz500_change"] = by.get("000905", {}).get("change_pct") or by.get("000905", {}).get("change_percent")
    # 风控摘要（尽量短）
    if isinstance(risk, dict) and isinstance(risk.get("data"), dict):
        rdata = risk["data"]
        flat["risk_level"] = rdata.get("risk_level") or rdata.get("level")
        flat["var_snapshot"] = rdata.get("var") or rdata.get("VaR")
        flat["max_dd_snapshot"] = rdata.get("max_drawdown") or rdata.get("max_dd")
        flat["current_dd_snapshot"] = rdata.get("current_drawdown") or rdata.get("current_dd")
        flat["position_risk_snapshot"] = rdata.get("position_note") or rdata.get("position")
    mr["inspection_flat"] = flat

    rd["midday_recap"] = mr
    if errors:
        rd["runner_errors"] = errors
    return rd, errors


def tool_run_midday_recap_and_send(
    mode: str = "prod",
    fetch_mode: str = "production",
    webhook_url: Optional[str] = None,
    secret: Optional[str] = None,
    keyword: Optional[str] = None,
    split_markdown_sections: bool = True,
    max_chars_per_message: Optional[int] = None,
) -> Dict[str, Any]:
    """
    进程内执行午间盘点采集并发送钉钉（report_type=midday_recap）。
    """
    report_data, _errors = build_midday_recap_report_data(fetch_mode=fetch_mode)
    mr = report_data.get("midday_recap") if isinstance(report_data.get("midday_recap"), dict) else {}
    title = f"午间行情盘点与下午操作指引 - {mr.get('date') or datetime.now().strftime('%Y-%m-%d')}"

    lines: List[str] = [
        title,
        "",
        "## 📊 午间盘点（简版）",
        f"- **生成时间**：{report_data.get('generated_at') or datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"- **半日状态**：{mr.get('market_state_label') or 'N/A'}",
        "",
        "### 资金流向（说明）",
        f"- {mr.get('fund_flow_data_note') or 'N/A'}",
        "",
        "### 板块热度（涨停侧）",
        "- 若接口返回 sectors，则在完整版模板中展示；此处仅保证投递链路可用。",
        "",
        "### 下午倾向（占位）",
        f"- {mr.get('afternoon_bias') or 'N/A'}：{mr.get('afternoon_bias_rationale') or 'N/A'}",
    ]
    errs = report_data.get("runner_errors")
    if isinstance(errs, list) and errs:
        lines.append("")
        lines.append("### ⚠️ 采集告警（摘要）")
        for e in errs[:6]:
            if isinstance(e, dict):
                lines.append(f"- {e.get('step')}: {e.get('error')}")
    message = "\n".join(lines).strip()

    from .send_dingtalk_message import tool_send_dingtalk_message

    out = tool_send_dingtalk_message(
        message=message,
        title=title,
        webhook_url=webhook_url,
        secret=secret,
        keyword=keyword,
        mode=mode,
        split_markdown_sections=bool(split_markdown_sections),
        max_chars_per_message=max_chars_per_message,
    )
    if isinstance(out, dict):
        data = dict(out.get("data") or {})
        data["runner_errors"] = report_data.get("runner_errors") or []
        data["report_type"] = "midday_recap"
        out["data"] = data
    return out

