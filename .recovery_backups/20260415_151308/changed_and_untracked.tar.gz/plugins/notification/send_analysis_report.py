from __future__ import annotations

from typing import Any, Dict, Optional


def tool_send_analysis_report(
    report_data: Dict[str, Any],
    report_date: Optional[str] = None,
    webhook_url: Optional[str] = None,
    mode: str = "prod",
    **kwargs: Any,
) -> Dict[str, Any]:
    """
    兼容工具：发送“分析类结构化报告”到钉钉。

    说明：
    - 旧工作流/runner 依赖 `tool_send_analysis_report`；
    - 当前实现复用 `tool_send_daily_report`（同一套钉钉发送与分段逻辑）。
    """
    from .send_daily_report import tool_send_daily_report

    return tool_send_daily_report(
        report_data=report_data,
        report_date=report_date,
        webhook_url=webhook_url,
        mode=mode,
        **kwargs,
    )

