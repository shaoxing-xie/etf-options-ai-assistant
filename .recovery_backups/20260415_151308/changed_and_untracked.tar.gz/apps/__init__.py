"""Apps package for auxiliary UIs and servers."""

