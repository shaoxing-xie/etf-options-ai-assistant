from __future__ import annotations

from typing import Any

from apps.chart_console.api.services import ApiServices
from src.services.backtest_service import BacktestConfig


def _first(query: dict[str, list[str]], key: str, default: str | None = None) -> str | None:
    v = query.get(key)
    if not v:
        return default
    if isinstance(v, list) and v:
        return str(v[0])
    return default


class ApiRoutes:
    """Route dispatcher for the embedded HTTP server.

    This keeps the API tiny and dependency-free (no FastAPI/Flask) so it can
    run inside the repo venv with minimal overhead.
    """

    def __init__(self, services: ApiServices) -> None:
        self.svc = services

    def handle_get(self, path: str, query: dict[str, list[str]]) -> tuple[dict[str, Any], int]:
        if path in ("/api/health", "/api/ping"):
            return self.svc.health(), 200

        if path == "/api/ohlcv":
            symbol = _first(query, "symbol", "") or ""
            data_type = _first(query, "data_type", "etf_daily") or "etf_daily"
            period = _first(query, "period")
            lookback_days_raw = _first(query, "lookback_days", "180") or "180"
            try:
                lookback_days = int(float(lookback_days_raw))
            except Exception:
                lookback_days = 180
            if not symbol:
                return {"success": False, "message": "missing symbol"}, 400
            resp = self.svc.market.get_ohlcv(
                symbol=symbol,
                data_type=data_type,
                period=period,
                lookback_days=lookback_days,
            )
            df = resp.get("data")
            if resp.get("success") and df is not None:
                resp = dict(resp)
                resp["data"] = df.to_dict("records")
            return resp, 200 if resp.get("success") else 502

        if path == "/api/indicators":
            symbol = _first(query, "symbol", "") or ""
            data_type = _first(query, "data_type", "etf_daily") or "etf_daily"
            lookback_days_raw = _first(query, "lookback_days", "180") or "180"
            timeframe_raw = _first(query, "timeframe_minutes")
            ma_raw = _first(query, "ma_periods")
            indicators_raw = _first(query, "indicators")
            try:
                lookback_days = int(float(lookback_days_raw))
            except Exception:
                lookback_days = 180
            timeframe_minutes = None
            if timeframe_raw:
                try:
                    timeframe_minutes = int(float(timeframe_raw))
                except Exception:
                    timeframe_minutes = None
            ma_periods = None
            if ma_raw:
                try:
                    ma_periods = [int(x) for x in str(ma_raw).split(",") if str(x).strip()]
                except Exception:
                    ma_periods = None
            indicators = None
            if indicators_raw:
                indicators = [s.strip() for s in str(indicators_raw).split(",") if s.strip()]
            if not symbol:
                return {"success": False, "message": "missing symbol"}, 400
            resp = self.svc.indicators.calculate(
                symbol=symbol,
                data_type=data_type,
                indicators=indicators,
                lookback_days=lookback_days,
                timeframe_minutes=timeframe_minutes,
                ma_periods=ma_periods,
            )
            return resp, 200 if resp.get("success") else 502

        if path == "/api/workspaces":
            return {"success": True, "data": self.svc.workspaces.list_workspaces()}, 200

        if path == "/api/backtest":
            symbol = _first(query, "symbol", "") or ""
            if not symbol:
                return {"success": False, "message": "missing symbol"}, 400
            def _to_int(name: str, default: int) -> int:
                raw = _first(query, name, str(default)) or str(default)
                try:
                    return int(float(raw))
                except Exception:
                    return default
            def _to_float(name: str, default: float) -> float:
                raw = _first(query, name, str(default)) or str(default)
                try:
                    return float(raw)
                except Exception:
                    return default
            cfg = BacktestConfig(
                symbol=symbol,
                lookback_days=_to_int("lookback_days", 240),
                fast_ma=_to_int("fast_ma", 10),
                slow_ma=_to_int("slow_ma", 30),
                fee_bps=_to_float("fee_bps", 3.0),
                slippage_bps=_to_float("slippage_bps", 2.0),
                capital=_to_float("capital", 1.0),
            )
            resp = self.svc.backtest.run_ma_crossover(cfg)
            data = resp.get("data")
            if resp.get("success") and isinstance(data, dict):
                series = data.get("series")
                if series is not None:
                    resp = dict(resp)
                    data = dict(data)
                    data["series"] = series.to_dict("records")
                    resp["data"] = data
            return resp, 200 if resp.get("success") else 502

        if path == "/api/alerts/config":
            return self.svc.alerts.get_alerts_text(), 200

        if path == "/api/alerts/replay":
            limit_raw = _first(query, "limit", "200") or "200"
            try:
                limit = int(float(limit_raw))
            except Exception:
                limit = 200
            return self.svc.alerts.get_recent_alert_events(limit=limit), 200

        if path == "/api/workspace":
            name = _first(query, "name", "") or ""
            if not name:
                return {"success": False, "message": "missing name"}, 400
            item = self.svc.workspaces.get_workspace(name)
            if not item:
                return {"success": False, "message": "not found"}, 404
            return {"success": True, "data": item}, 200

        return {"success": False, "message": "not found"}, 404

    def handle_post(self, path: str, body: dict[str, Any]) -> tuple[dict[str, Any], int]:
        if path == "/api/workspace/save":
            name = str(body.get("name", "") or "").strip()
            state = body.get("state")
            if not name:
                return {"success": False, "message": "missing name"}, 400
            if not isinstance(state, dict):
                return {"success": False, "message": "missing state"}, 400
            try:
                rec = self.svc.workspaces.save_workspace(name, state)
            except Exception as e:
                return {"success": False, "message": str(e)}, 400
            return {"success": True, "data": rec}, 200

        if path == "/api/workspace/delete":
            name = str(body.get("name", "") or "").strip()
            if not name:
                return {"success": False, "message": "missing name"}, 400
            ok = self.svc.workspaces.delete_workspace(name)
            return {"success": True, "data": {"deleted": ok}}, 200

        if path == "/api/alerts/config/save":
            text = body.get("text")
            if not isinstance(text, str):
                return {"success": False, "message": "missing text"}, 400
            resp = self.svc.alerts.save_alerts_text(text)
            return resp, 200 if resp.get("success") else 400

        return {"success": False, "message": "not found"}, 404

