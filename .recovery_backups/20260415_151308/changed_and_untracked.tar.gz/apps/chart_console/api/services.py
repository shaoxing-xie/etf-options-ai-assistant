from __future__ import annotations

from typing import Any

from src.services.alerts_config_service import AlertsConfigService
from src.services.backtest_service import BacktestService
from src.services.indicator_service import IndicatorService
from src.services.market_data_service import MarketDataService
from src.services.workspace_service import WorkspaceService


class ApiServices:
    """Dependency container for the chart console HTTP API."""

    def __init__(self) -> None:
        self.market = MarketDataService()
        self.indicators = IndicatorService()
        self.backtest = BacktestService()
        self.workspaces = WorkspaceService()
        self.alerts = AlertsConfigService()

    def health(self) -> dict[str, Any]:
        return {"success": True, "message": "ok"}

