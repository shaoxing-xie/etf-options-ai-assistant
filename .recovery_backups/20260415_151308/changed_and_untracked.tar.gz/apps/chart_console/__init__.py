"""Chart console (Streamlit UI + lightweight HTTP API)."""

