from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml


class AlertsConfigService:
    """Read/write alerts config for non-Streamlit chart console."""

    def __init__(self, root_dir: Path | None = None) -> None:
        self.root_dir = root_dir or Path(__file__).resolve().parents[2]
        self.alerts_path = self.root_dir / "config" / "alerts.yaml"
        self.events_path = self.root_dir / "data" / "alerts" / "internal_alert_events.jsonl"

    def get_alerts_text(self) -> dict[str, Any]:
        if not self.alerts_path.exists():
            return {"success": False, "message": "alerts.yaml not found", "data": {"text": "", "path": str(self.alerts_path)}}
        text = self.alerts_path.read_text(encoding="utf-8")
        return {"success": True, "message": "ok", "data": {"text": text, "path": str(self.alerts_path)}}

    def save_alerts_text(self, text: str) -> dict[str, Any]:
        clean = str(text or "")
        # Validate YAML before overwriting production config.
        try:
            parsed = yaml.safe_load(clean) if clean.strip() else {}
            if parsed is None:
                parsed = {}
            if not isinstance(parsed, dict):
                return {"success": False, "message": "alerts.yaml must be a YAML object"}
        except Exception as e:
            return {"success": False, "message": f"invalid yaml: {e}"}

        self.alerts_path.parent.mkdir(parents=True, exist_ok=True)
        if self.alerts_path.exists():
            ts = datetime.now().strftime("%Y%m%d-%H%M%S")
            backup = self.alerts_path.with_name(f"alerts.yaml.bak.{ts}")
            backup.write_text(self.alerts_path.read_text(encoding="utf-8"), encoding="utf-8")
        self.alerts_path.write_text(clean, encoding="utf-8")
        return {"success": True, "message": "saved", "data": {"path": str(self.alerts_path)}}

    def get_recent_alert_events(self, limit: int = 200) -> dict[str, Any]:
        if not self.events_path.exists():
            return {"success": True, "message": "no events file", "data": []}
        lines = self.events_path.read_text(encoding="utf-8").splitlines()
        out: list[dict[str, Any]] = []
        for line in lines[-max(1, int(limit)) :]:
            s = line.strip()
            if not s:
                continue
            try:
                obj = json.loads(s)
            except Exception:
                continue
            if isinstance(obj, dict):
                out.append(obj)
        return {"success": True, "message": "ok", "data": out}

