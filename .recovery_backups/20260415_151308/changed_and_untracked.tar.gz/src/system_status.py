from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time
from typing import Any, Dict, Optional


def _tz_shanghai():
    """
    Return a tzinfo for Asia/Shanghai.

    Prefer stdlib zoneinfo; fall back to pytz if available (older code paths).
    """
    try:
        from zoneinfo import ZoneInfo

        return ZoneInfo("Asia/Shanghai")
    except Exception:
        try:
            import pytz

            return pytz.timezone("Asia/Shanghai")
        except Exception:
            return None


def get_trading_hours_config(config: Dict) -> Dict:
    """
    Backward-compatible wrapper.

    A few modules import this from `src.system_status`, while the canonical
    implementation lives in `src.config_loader`.
    """
    from src.config_loader import get_trading_hours_config as _get

    return _get(config)


def is_trading_day(dt: datetime | date, config: Optional[Dict] = None) -> bool:
    """
    Whether a given date/datetime is a trading day.

    Rules:
    - Weekend is non-trading
    - Holidays in config are non-trading
    """
    if isinstance(dt, datetime):
        d = dt.date()
    else:
        d = dt

    if d.weekday() >= 5:
        return False

    if config is None:
        from src.config_loader import load_system_config

        config = load_system_config(use_cache=True)

    from src.config_loader import get_holidays_config

    holidays = get_holidays_config(config)
    return d.strftime("%Y%m%d") not in holidays


@dataclass(frozen=True)
class _TradingHours:
    morning_start: time
    morning_end: time
    afternoon_start: time
    afternoon_end: time


def _parse_hhmm(v: Any, default: str) -> time:
    s = str(v or default).strip()
    try:
        hh, mm = s.split(":", 1)
        return time(hour=int(hh), minute=int(mm))
    except Exception:
        hh, mm = default.split(":", 1)
        return time(hour=int(hh), minute=int(mm))


def _get_hours(config: Dict) -> _TradingHours:
    th = get_trading_hours_config(config) or {}
    return _TradingHours(
        morning_start=_parse_hhmm(th.get("morning_start"), "09:30"),
        morning_end=_parse_hhmm(th.get("morning_end"), "11:30"),
        afternoon_start=_parse_hhmm(th.get("afternoon_start"), "13:00"),
        afternoon_end=_parse_hhmm(th.get("afternoon_end"), "15:00"),
    )


def get_current_market_status(config: Optional[Dict] = None, now: Optional[datetime] = None) -> Dict[str, Any]:
    """
    Return current market status for A-share style trading hours.

    Output keys (used by callers):
    - status: one of before_open|trading|lunch_break|after_close|non_trading_day
    - is_trading_time: bool
    - current_time: formatted string
    """
    if config is None:
        from src.config_loader import load_system_config

        config = load_system_config(use_cache=True)

    tz = _tz_shanghai()
    if now is None:
        now = datetime.now(tz) if tz else datetime.now()
    else:
        # normalize timezone for consistent comparisons
        if tz and now.tzinfo is None:
            try:
                now = now.replace(tzinfo=tz)
            except Exception:
                pass

    cur_t = now.timetz().replace(tzinfo=None) if hasattr(now, "timetz") else now.time()
    hours = _get_hours(config)

    if not is_trading_day(now, config):
        return {
            "status": "non_trading_day",
            "is_trading_time": False,
            "current_time": now.strftime("%Y-%m-%d %H:%M:%S"),
        }

    if cur_t < hours.morning_start:
        status = "before_open"
        is_trading_time = False
    elif hours.morning_start <= cur_t <= hours.morning_end:
        status = "trading"
        is_trading_time = True
    elif hours.morning_end < cur_t < hours.afternoon_start:
        status = "lunch_break"
        is_trading_time = False
    elif hours.afternoon_start <= cur_t <= hours.afternoon_end:
        status = "trading"
        is_trading_time = True
    else:
        status = "after_close"
        is_trading_time = False

    return {
        "status": status,
        "is_trading_time": is_trading_time,
        "current_time": now.strftime("%Y-%m-%d %H:%M:%S"),
    }

